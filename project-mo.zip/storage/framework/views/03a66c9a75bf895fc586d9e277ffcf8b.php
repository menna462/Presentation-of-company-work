<?php $__env->startSection('content'); ?>
    <!-- الصفحة الرئيسية -->
    <section id="home">
        <div class="hero">
            <h1 class="animate__fadeInCustom">شركة SESCC للمقاولات الهندسية</h1>
            <p class="animate__fadeInCustom animate__delay-1s">نقدم حلولاً هندسية متكاملة بمعايير الجودة العالمية</p>
            <a href="#contact" class="btn animate__zoomIn">تواصل معنا</a>
        </div>
    </section>

<?php echo $__env->make('include.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('include.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('include.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('include.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project-mo\resources\views/welcome.blade.php ENDPATH**/ ?>