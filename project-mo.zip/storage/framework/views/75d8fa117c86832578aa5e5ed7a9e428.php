<?php $__env->startSection('main'); ?>
<div class="container ">
    <div class="row">
      <div class="col-md-8  align-items-center ">
        <h3 class="text-center mb-3">Details of product <span class="badge badge-primary"><?php echo e($about ->count()); ?></span> </h3>
        <table class="table ">
          <thead>
            <tr>
                    <td>ID</td>
                    <td>Title</td>
                    <td>Paragraph</td>
                    <td>Image</td>
                    <td>Operation</td>
            </tr>
          </thead>
          <tbody>
              <tr>
                  <td> <?php echo e($about->id); ?> </td>
                  <td> <?php echo e($about->title); ?> </td>
                  <td><?php echo e($about->paragraph); ?></td>
                    <img src="<?php echo e(asset('storage/' . $about->image)); ?>" width="100" alt="Image">
                  <td>
                  <a href=<?php echo e(route('about')); ?> class="btn btn-success">
                    <i class="fa-solid fa-house"></i>
                  </a>
                  </td>
              </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dashboard-laravel\resources\views/backend/about/show.blade.php ENDPATH**/ ?>