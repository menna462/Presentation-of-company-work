<?php $__env->startSection('main'); ?>
    <div class="container ">
        <div class="row">
            <div class="col-md-8  align-items-center ">
                <h3 class="text-center mb-3">Details of product <span
                        class="badge badge-primary"><?php echo e($contacts->count()); ?></span> </h3>
                <table class="table ">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Map</th>
                            <th>Operations</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td> <?php echo e($contacts->id); ?> </td>
                            <td> <?php echo e($contacts->phone); ?> </td>
                            <td><?php echo e($contacts->email); ?></td>
                            <td><?php echo e($contacts->address); ?></td>
                            <td><?php echo e($contacts->location_map); ?></td>
                            <td>
                                <a href=<?php echo e(route('contacts')); ?> class="btn btn-success">
                                    <i class="fa-solid fa-house"></i>
                                </a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dashboard-laravel\resources\views/backend/contact/show.blade.php ENDPATH**/ ?>