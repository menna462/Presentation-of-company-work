<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 m-auto">
                <form action="<?php echo e(route('category.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="old_id" value="<?php echo e($result->id); ?>">

                    <label for="">Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $result->name)); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                    <input type="submit" class="btn btn-success btn-block mt-4" value="Update About">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project-mo\resources\views/backend/category/edit.blade.php ENDPATH**/ ?>