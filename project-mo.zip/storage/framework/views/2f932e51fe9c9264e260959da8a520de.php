<?php $__env->startSection('main'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- DataTales Example -->
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>

            </div>
            <a href="<?php echo e(route('news.create')); ?>" class="btn btn-success"> Create New News</a>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Title</th>
                                <th>Paragraph</th>
                                <th>Image</th>
                                <th>operation</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e(Str::limit($item->paragraph, 30)); ?></td>
                                    <td>
                                        <?php if($item->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $item->image)); ?>" width="100" alt="Image">
                                        <?php else: ?>
                                            لا توجد صورة
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href=<?php echo e(route('news.show', $item->id)); ?> class="btn btn-success"><i
                                                class="fa-solid fa-eye"></i></a>

                                        <a href=<?php echo e(route('news.edit', $item->id)); ?> class="btn btn-primary"><i
                                                class="fa-solid fa-pen-to-square"></i></a>

                                        <a href=<?php echo e(route('news.delete', $item->id)); ?> class="btn btn-success">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <br>
        <br>

    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dashboard-laravel\resources\views/backend/news.blade.php ENDPATH**/ ?>