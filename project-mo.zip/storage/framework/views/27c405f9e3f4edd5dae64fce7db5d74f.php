<?php $__env->startSection('main'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- DataTales Example -->
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>

            </div>
            <a href="<?php echo e(route('contact.create')); ?>" class="btn btn-success"> Create New User</a>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Map</th>
                                <th>Operations</th>

                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->phone); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e(Str::limit($item->address, 30)); ?></td>
                                    <td><?php echo e(Str::limit($item->location_map, 20)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('contact.show', $item->id)); ?>" class="btn btn-info"><i
                                                class="fa-solid fa-eye"></i></a>
                                        <a href="<?php echo e(route('contact.edit', $item->id)); ?>" class="btn btn-primary"><i
                                                class="fa-solid fa-pen-to-square"></i></a>
                                        <a href="<?php echo e(route('contact.delete', $item->id)); ?>" class="btn btn-danger"><i class="fa-solid fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <br>
        <br>

    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dashboard-laravel\resources\views/backend/contacts.blade.php ENDPATH**/ ?>