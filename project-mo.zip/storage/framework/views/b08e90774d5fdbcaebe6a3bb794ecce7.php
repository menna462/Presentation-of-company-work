<!-- قسم الخدمات -->
<section id="services" class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5 fw-bold text-primary">خدماتنا</h2>

        <div class="row g-4">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card h-200  shadow border-0 service-card text-center">
                        <img src="<?php echo e(asset($service->image)); ?>" class="card-img-top img-fluid" alt="<?php echo e($service->title); ?>">
                        <div class="card-body">
                            <h5 class="card-title fw-bold"><?php echo e($service->title); ?></h5>
                            <p class="card-text text-muted"><?php echo e($service->paragraph); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="text-center mt-5">
            <a href="<?php echo e(route('allServices')); ?>" class="btn btn-primary btn-lg rounded-pill px-5">
                عرض المزيد من الخدمات
            </a>
        </div>
    </div>
</section>
<?php /**PATH C:\project-mo\resources\views/include/services.blade.php ENDPATH**/ ?>