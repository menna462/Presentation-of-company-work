    <!-- قسم من نحن -->
    <section id="about">
        <div class="container">
            <h2 class="animate__fadeInCustom">من نحن</h2>
            <div class="about-content">
                <div class="about-text animate__slideInLeft">
                    <h3>شركة المقاولات المستدامة (SESCC)</h3>
                    <p>SESCC هي شركة رائدة في مجال المقاولات والهندسة، ملتزمة بتقديم مشاريع عالية الجودة ومستدامة. تتخصص
                        الشركة في مجموعة واسعة من الخدمات، مع ضمان التميز في التنفيذ والالتزام بأحدث المعايير العالمية.
                    </p>
                    <h4>رؤيتنا</h4>
                    <p>تهدف SESCC إلى تحويل الرؤى التقنية إلى واقع ملموس، من خلال الجمع بين الابتكار والاستدامة والدقة
                        في كل مشروع.</p>
                    <h4>الالتزام بالجودة</h4>
                    <p>تلتزم SESCC باستخدام أحدث التقنيات والالتزام بأعلى معايير الجودة والسلامة، والتعاون مع شركاء
                        عالميين لضمان توفر أفضل المواد والمعدات، وتقديم مشاريع تجمع بين الجمال والوظيفية.</p>
                </div>
                <div class="about-image animate__slideInRight">
                    <img src="<?php echo e(asset('frontend/image/istockphoto-1627235585-612x612.webp')); ?>" alt="فريق العمل">
                </div>
            </div>
        </div>
    </section>
<?php /**PATH C:\project-mo\resources\views/include/about.blade.php ENDPATH**/ ?>