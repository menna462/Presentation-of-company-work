<?php $__env->startSection('content'); ?>

<section id="all-services">
    <div class="container">
        <h2>جميع الخدمات</h2>
        <div class="services-grid">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="service-card">
                    <img src="<?php echo e(asset($service->image)); ?>" alt="<?php echo e($service->title); ?>">
                    <h3><?php echo e($service->title); ?></h3>
                    <p><?php echo e($service->paragraph); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project-mo\resources\views/include/allservices.blade.php ENDPATH**/ ?>