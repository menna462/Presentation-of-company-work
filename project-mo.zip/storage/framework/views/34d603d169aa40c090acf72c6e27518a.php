    <!-- قسم المشاريع -->
    <section id="projects">
        <div class="container">
            <h2 class="animate__fadeInCustom">مشاريعنا</h2>
            <!-- أزرار التصفية -->
            <div class="filter-buttons animate__fadeInCustom">
                <button class="filter-btn active" data-filter="all">الكل</button>
                <button class="filter-btn" data-filter="residential">سكني</button>
                <button class="filter-btn" data-filter="commercial">تجاري</button>
                <button class="filter-btn" data-filter="industrial">صناعي</button>
                <button class="filter-btn" data-filter="infrastructure">بنية تحتية</button>
            </div>
            <div class="projects-grid">
                <div class="project-card animate__fadeInCustom" data-category="residential">
                    <img src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80"
                        alt="مجمع سكني">
                    <div class="project-info">
                        <h3>مجمع سكني فاخر</h3>
                        <p>تنفيذ مجمع سكني مكون من 10 فلل في منطقة الرياض</p>
                        <span class="category">سكني</span>
                    </div>
                </div>
                <div class="project-card animate__fadeInCustom" data-category="commercial">
                    <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80"
                        alt="مركز تجاري">
                    <div class="project-info">
                        <h3>مركز تجاري حديث</h3>
                        <p>تصميم وتنفيذ مركز تجاري بمساحة 20,000 م² في جدة</p>
                        <span class="category">تجاري</span>
                    </div>
                </div>
                <div class="project-card animate__fadeInCustom" data-category="industrial">
                    <img src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?ixlib=rb-4.0.3&auto=format&fit=crop&w=1413&q=80"
                        alt="مصنع">
                    <div class="project-info">
                        <h3>مصنع متكامل</h3>
                        <p>إنشاء مصنع للأغذية بمواصفات عالمية في الدمام</p>
                        <span class="category">صناعي</span>
                    </div>
                </div>
                <div class="project-card animate__fadeInCustom" data-category="infrastructure">
                    <img src="https://images.unsplash.com/photo-1541625602330-2277a4c46182?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80"
                        alt="جسر">
                    <div class="project-info">
                        <h3>جسر رئيسي</h3>
                        <p>تصميم وتنفيذ جسر بطول 500 متر في المدينة المنورة</p>
                        <span class="category">بنية تحتية</span>
                    </div>
                </div>
                <div class="project-card animate__fadeInCustom" data-category="residential">
                    <img src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80"
                        alt="عمارة سكنية">
                    <div class="project-info">
                        <h3>عمارة سكنية</h3>
                        <p>بناء عمارة سكنية مكونة من 12 شقة في مكة المكرمة</p>
                        <span class="category">سكني</span>
                    </div>
                </div>
                <div class="project-card animate__fadeInCustom" data-category="commercial">
                    <img src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-4.0.3&auto=format&fit=crop&w=1469&q=80"
                        alt="فندق">
                    <div class="project-info">
                        <h3>فندق 5 نجوم</h3>
                        <p>تشييد فندق فاخر بمواصفات عالمية في العاصمة الرياض</p>
                        <span class="category">تجاري</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php /**PATH C:\project-mo\resources\views/include/projects.blade.php ENDPATH**/ ?>