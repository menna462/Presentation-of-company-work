<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 m-auto">
            <h3 class="text-center mb-4">
                تفاصيل المنتج
            </h3>

            <table class="table table-bordered table-striped text-center">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>اسم المنتج</th>
                        <th>الوصف</th>
                        <th>الفئة</th>
                        <th>العمليات</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td><?php echo e($product->category?->name ?? 'غير محدد'); ?></td>

                        <td>
                            <a href="<?php echo e(route('product')); ?>" class="btn btn-sm btn-primary" title="العودة">
                                <i class="fa fa-arrow-left"></i> العودة
                            </a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project-mo\resources\views/backend/product/show.blade.php ENDPATH**/ ?>