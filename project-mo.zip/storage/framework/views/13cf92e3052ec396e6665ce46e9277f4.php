<?php $__env->startSection('main'); ?>
<div class="container ">
    <div class="row">
      <div class="col-md-8  align-items-center ">
        <h3 class="text-center mb-3">Details of product <span class="badge badge-primary"><?php echo e($users ->count()); ?></span> </h3>
        <table class="table ">
          <thead>
            <tr>
                    <td>ID</td>
                    <td>Name</td>
                    <td>Email</td>
                    <td>Password</td>
                    <td>Operation</td>
            </tr>
          </thead>
          <tbody>
              <tr>
                  <td> <?php echo e($users->id); ?> </td>
                  <td> <?php echo e($users->name); ?> </td>
                  <td><?php echo e($users->email); ?></td>
                  <td><?php echo e($users->password); ?></td>
                  <td>
                  <a href=<?php echo e(route('users')); ?> class="btn btn-success">
                    <i class="fa-solid fa-house"></i>
                  </a>
                  </td>
              </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project-mo\resources\views/backend/users/show.blade.php ENDPATH**/ ?>