<style>
    .products-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }

    .product-card {
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 16px;
        text-align: center;
        transition: box-shadow 0.3s ease;
        background-color: #fff;
    }

    .product-card:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .product-card img {
        max-width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 4px;
        margin-bottom: 12px;
    }

    .product-card h3 {
        font-size: 1.2rem;
        margin: 8px 0;
    }

    .product-card p {
        color: #555;
        font-size: 0.95rem;
        margin-bottom: 12px;
    }

    .product-card .btn {
        display: inline-block;
        padding: 8px 16px;
        background-color: #007bff;
        color: white;
        text-decoration: none;
        border-radius: 4px;
    }

    .product-card .btn:hover {
        background-color: #0056b3;
    }
</style>

<section id="products">
    <div class="container">
        <h2>مشاريعنا</h2>
        <div class="products-grid">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-card">
                    
                    <?php if($product->images->first()): ?>
                        <img src="<?php echo e(asset('imges/products/' . $product->images->first()->image_path)); ?>" alt="صورة المنتج">
                    <?php else: ?>
                        <img src="<?php echo e(asset('imges/products/default.png')); ?>" alt="صورة افتراضية">
                    <?php endif; ?>

                    <h3><?php echo e($product->name); ?></h3>
                    <p><?php echo e($product->description); ?></p>
                    <a href="<?php echo e(route('productshow', $product->id)); ?>" class="btn">عرض التفاصيل</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="text-center mt-4">
            <a href="<?php echo e(route('allProducts')); ?>" class="btn btn-primary">عرض كل المشاريع</a>
        </div>
    </div>
</section>

<?php /**PATH C:\project-mo\resources\views/include/product.blade.php ENDPATH**/ ?>