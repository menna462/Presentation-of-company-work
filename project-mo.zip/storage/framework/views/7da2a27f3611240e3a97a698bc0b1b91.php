<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 m-auto">
                <form action=<?php echo e(route('imgproduct.update')); ?> method="post" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="old_id" value=<?php echo e($result->id); ?>>
                    <label for="">Img</label>
                    <input type="file" name="image_path" class="form-control">
                    <!-- عرض الصورة الحالية -->
                    <?php if($result->image_path): ?>
                        <?php
                            $ext = pathinfo($result->image_path, PATHINFO_EXTENSION);
                        ?>
                        <div class="mt-3 mb-3">
                            <label>الملف الحالي:</label>
                            <br>
                            <?php if(in_array(strtolower($ext), ['mp4', 'webm', 'ogg'])): ?>
                                <video width="250" height="150" controls style="border:1px solid #ccc; padding:5px;">
                                    <source src="<?php echo e(asset('imges/products/' . $result->image_path)); ?>"
                                        type="video/<?php echo e($ext); ?>">
                                    المتصفح لا يدعم عرض الفيديو.
                                </video>
                            <?php else: ?>
                                <img src="<?php echo e(asset('imges/products/' . $result->image_path)); ?>" width="150"
                                    alt="Current Media" style="border:1px solid #ccc; padding:5px;">
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>


                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <!-- حقل اختيار المنتج -->
                    <label for="">Product</label>
                    <select name="product_id" class="form-control">
                        <option value="">اختار منتج</option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>" <?php echo e($result->product_id == $product->id ? 'selected' : ''); ?>>
                                <?php echo e($product->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="submit" class="btn btn-success btn-block mt-5" value="Edit Product">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project-mo\resources\views/backend/imgproduct/edit.blade.php ENDPATH**/ ?>